package question2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Question2Test {
    public static void main(String[] args) {
        List<Integer> list1 = new ArrayList<>(Arrays.asList(3,5,8,13,21,34,55));
        List<Integer> list2 = new ArrayList<>(Arrays.asList(1,3,8,11,23,34,57));

        Collections.sort(list1);
        Collections.sort(list2);
        System.out.print("L1: ");
        for (Integer val : list1) {
            System.out.print("[" + val + "]");
        }
        System.out.println();
        System.out.print("L2: ");
        for (Integer val : list2) {
            System.out.print("[" + val + "]");
        }
        System.out.println();
        List<Integer> L3 = Question2.returnUnionOfSortedLists(list1, list2);
        System.out.print("L3: ");
        for (Integer val : L3) {
            System.out.print("[" + val + "]");
        }

    }
}