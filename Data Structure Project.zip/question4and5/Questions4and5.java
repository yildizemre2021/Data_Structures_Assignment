import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
/**
 * 190315003 - Z�lf�kar Minaz
 * 200315092 - Emre Y�ld�z
 * 200315070 - Eren �etiner
 */
public class Questions4and5 {

    public static void main(String[] args) throws IOException {
        
        String fileName = "sample.txt";
        String line;
        try {
            FileReader read = new FileReader(fileName);
            BufferedReader bRead = new BufferedReader(read);
            List<String> list = new ArrayList();
            String[] arr = null;
            while ((line = bRead.readLine()) != null) {
                line = line.toLowerCase();
                arr = line.split(" ");
                for (String s : arr) {
                    if (s.equalsIgnoreCase(""));
                    else {
                        list.add(s);
                    }
                }
            }
            bRead.close();
            HashSet<String> set =  new HashSet<>(list);
            System.out.println("Question 4 Solution :");
            System.out.println("Distinct word size = " + set.size());
            System.out.println("\nQuestion 5 Solution :");
            for (String str : set)
                System.out.print(str + "=" + Collections.frequency(list, str) + ", ");
        }
        catch (IOException iox) {
            System.out.println(fileName + " could not read.");
        }
    }
}